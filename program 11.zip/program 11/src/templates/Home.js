const Home = () => {
    return <h1>Welcome to CMRIT Home Page</h1>;
  };
  
  export default Home;